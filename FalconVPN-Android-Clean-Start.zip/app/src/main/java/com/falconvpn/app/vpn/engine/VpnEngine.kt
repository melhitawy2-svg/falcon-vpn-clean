package com.falconvpn.app.vpn.engine

/**
 * Contract between Falcon VPN's UI/config manager and a concrete VPN engine.
 * This interface deliberately does not pretend to establish a tunnel by itself.
 * Implementations must wrap a real, licensed engine and report actual state.
 */
interface VpnEngine {
    val id: String
    val supportedProtocols: Set<String>

    fun validateConfig(protocol: String, rawConfig: String): ConfigValidation

    /** Start a connection using a platform-approved configuration. */
    suspend fun connect(config: EngineConfig): EngineResult

    /** Stop an active connection. */
    suspend fun disconnect(): EngineResult
}

data class EngineConfig(
    val profileId: Long,
    val displayName: String,
    val protocol: String,
    val rawConfig: String
)

data class ConfigValidation(
    val valid: Boolean,
    val message: String
)

data class EngineResult(
    val success: Boolean,
    val message: String
)

enum class VpnConnectionState {
    DISCONNECTED,
    NEEDS_PERMISSION,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    ERROR
}
